# Sahakar Sahayak — Accuracy Scoreboard

Generated 2026-09-27 20:47 · mode **search-only** · meaning search **off** · 2,655 passages from 11 official PDFs · 24 test questions

**Overall: 22/24 passed (91.67%)**

## Search quality

| Metric | Result |
|---|---|
| Correct document ranked #1 (Hit@1) | 80.95% |
| Correct document in top 3 (Hit@3) | 90.48% |
| Correct document in the 6 passages sent to the AI (Hit@6) | 95.24% |
| Mean reciprocal rank (MRR) | 0.8690 |
| Exact page found (Page@6) | 77.78% |
| Off-topic questions rejected by search | 66.67% |
| Search time (avg / p95) | 11.81 ms / 19.64 ms |

## By category

| Category | Questions | Correct document found |
|---|---|---|
| scheme | 13 | 92.31% |
| cooperative | 8 | 100.00% |

## Every question

| ID | Topic | Question | Result |
|---|---|---|---|
| S01 | PM-KISAN | How much money does a farmer get every year under PM-KISAN? | rank 1 |
| S02 | PM-KISAN | In how many installments is the PM-KISAN benefit paid and how much is each installment? | rank 1 |
| S03 | PM-KISAN | Are retired pensioners eligible for PM-KISAN benefits? | rank 1 |
| S04 | PM-KISAN | What is the cut-off date for land ownership eligibility under PM-KISAN? | rank 1 |
| S05 | PMFBY | Within how many hours must a farmer report crop loss due to localized calamities under PMFBY? | rank 1 |
| S06 | PMFBY | How can a farmer intimate crop loss under PMFBY, through which app or helpline? | rank 1 |
| S07 | KCC | Up to what amount are Kisan Credit Card loans given without collateral security? | rank — |
| S08 | KCC | What is the tenure of the KCC composite credit facility? | rank 1 |
| S09 | KCC | Who is a marginal farmer as per the RBI Kisan Credit Card directions? | rank 1 |
| S10 | KCC | What is the flexi KCC credit limit for marginal farmers? | rank 1 |
| S11 | UPIS | What is the age limit for farmers to join the Unified Package Insurance Scheme? | rank 1 |
| S12 | PMKSY | What subsidy do small and marginal farmers get for micro irrigation under PMKSY? | rank 1 |
| S13 | PMKSY | What is the central and state funding ratio for North Eastern and Himalayan states under PMKSY? | rank 4 |
| C01 | Karnataka Act | How often must a cooperative society in Karnataka get its accounts audited? | rank 1 |
| C02 | MSCS Amendment 2023 | Which authority conducts elections of multi-state cooperative societies after the 2023 amendment? | rank 2 |
| C03 | MSCS Amendment 2023 | Which fund was created for the revival of sick multi-state cooperative societies under the 2023 amendment? | rank 1 |
| C04 | Model Bye-laws | What percentage of net profit must a PACS transfer to its reserve fund every year under the model bye-laws? | rank 2 |
| C05 | Model Bye-laws | What is the maximum borrowing limit of a PACS compared to its paid-up share capital and reserves? | rank 1 |
| C06 | Model Bye-laws | Who decides the rate of dividend in a PACS? | rank 1 |
| C07 | PACS initiatives | What is the total financial outlay for the computerisation of PACS? | rank 1 |
| C08 | PACS initiatives | Can PACS run Jan Aushadhi Kendras to sell generic medicines? | rank 1 |
| O01 | Cricket | Who won the cricket world cup? | rejected ✓ |
| O02 | Movies | Suggest a good Bollywood movie to watch tonight | rejected ✓ |
| O03 | Politics | Which party will win the next general election? | rejected ✗ |

_Expected answers were checked by hand against the official PDFs. Run `python3 evaluate_rag.py --full` to reproduce._
