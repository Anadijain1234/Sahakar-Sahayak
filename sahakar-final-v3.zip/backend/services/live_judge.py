"""
Live "AI check" -- every answer is graded by OTHER AIs, never by the one that wrote it.

  Answer written by Sarvam      -> checked by Groq + Cloudflare
  Answer written by Groq        -> checked by Cloudflare + Sarvam
  Answer written by Cloudflare  -> checked by Groq + Sarvam
  Search-only answer            -> not checked (it is the PDF text itself)

How it works: /query remembers each answer for 30 minutes. Right after showing the
answer, the website calls POST /judge with the answer's request ID; the judges run in
parallel, the result is shown in the answer's scorecard and saved in the database
(admin insights). The answer itself is never delayed by the check.

There is no answer key for live questions, so the judges check:
  faithful  0-10  are the facts supported by the official passages given to the AI
                  (no passages: accurate general knowledge, no invented rules)
  helpful   0-10  does it directly and fully answer the question
  language  was it written in the language the user chose
  grade     good / partly / poor

Free-limit guard (per day, resets at midnight UTC), so the judges never use up the
backup AIs' free quota:
  LIVE_JUDGE=off                    turn the check off
  LIVE_JUDGE_GROQ_DAILY=120         Groq checks per day   (judge model: GROQ_JUDGE_MODEL, default gpt-oss-20b)
  LIVE_JUDGE_CLOUDFLARE_DAILY=80    Cloudflare checks per day
  LIVE_JUDGE_SARVAM_DAILY=200       Sarvam checks per day (only used when Groq or Cloudflare wrote the answer)
"""

import os
import re
import json
import time
import threading
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone

import requests

from backend.services import llm_chain
from backend.services.reqlog import log, set_request_id

ENABLED = os.getenv("LIVE_JUDGE", "on").strip().lower() not in ("off", "0", "false", "no")
GROQ_JUDGE_MODEL = os.getenv("GROQ_JUDGE_MODEL", "openai/gpt-oss-20b").strip()
DAILY_LIMIT = {
    "groq": int(os.getenv("LIVE_JUDGE_GROQ_DAILY", "120")),
    "cloudflare": int(os.getenv("LIVE_JUDGE_CLOUDFLARE_DAILY", "80")),
    "sarvam": int(os.getenv("LIVE_JUDGE_SARVAM_DAILY", "200")),
}
JUDGE_NAMES = {
    "groq": f"Groq · {GROQ_JUDGE_MODEL.split('/')[-1]}",
    "cloudflare": "Cloudflare · Llama 3.3 70B",
    "sarvam": "Sarvam · sarvam-105b",
}
LANG_NAMES = {"en": "English", "hi": "Hindi", "kn": "Kannada", "ne": "Nepali", "ta": "Tamil", "te": "Telugu",
              "ml": "Malayalam", "mr": "Marathi", "bn": "Bengali", "gu": "Gujarati", "pa": "Punjabi", "or": "Odia"}
TIMEOUT = 25
KEEP_SECONDS = 30 * 60

_answers = OrderedDict()      # request_id -> what the judges need
_results = {}                 # request_id -> finished check (so it only runs once)
_used = {}                    # "YYYY-MM-DD:judge" -> checks used today
_running = set()              # checks in progress (so a double click doesn't run them twice)
_lock = threading.Lock()


def remember(request_id, question, english_question, answer, language, trust_level, answered_by, passages):
    """Called by /query: keep what the judges will need (for 30 minutes)."""
    if not ENABLED or not request_id:
        return
    with _lock:
        _answers[request_id] = {
            "t": time.time(), "question": question or "", "english": english_question or "",
            "answer": answer or "", "language": language, "trust_level": trust_level,
            "answered_by": answered_by,
            "passages": [re.sub(r"\s+", " ", p)[:700] for p in (passages or [])[:3]],
        }
        while len(_answers) > 300:
            _answers.popitem(last=False)


def _judges_for(answered_by):
    if answered_by == "groq":
        return ["cloudflare", "sarvam"]
    if answered_by == "cloudflare":
        return ["groq", "sarvam"]
    return ["groq", "cloudflare"]          # Sarvam wrote it (the normal case)


def _take_quota(judge):
    day = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    key = f"{day}:{judge}"
    with _lock:
        if _used.get(key, 0) >= DAILY_LIMIT.get(judge, 0):
            return False
        _used[key] = _used.get(key, 0) + 1
        return True


SYSTEM = (
    "You are a strict, fair examiner checking an assistant that helps Indian farmers and cooperative-"
    "society members. You will see the user's question, the official document passages the assistant "
    "was given (may be empty), and the assistant's answer. Judge the answer. Reply with JSON only."
)


def _prompt(item):
    lang = LANG_NAMES.get(item["language"], "English")
    passages = "\n\n".join(f"[{i + 1}] {p}" for i, p in enumerate(item["passages"])) or "(none -- answered from general knowledge)"
    answer = item["answer"][:1500]
    return (
        f"QUESTION (the user chose {lang} for the answer):\n{item['question']}\n"
        f"(English meaning: {item['english']})\n\n"
        f"OFFICIAL PASSAGES GIVEN TO THE ASSISTANT:\n{passages}\n\n"
        f"ANSWER:\n{answer}\n\n"
        "Rules:\n"
        "- faithful (0-10): are the answer's facts, numbers and conditions supported by the passages? If there are "
        "no passages, are they accurate general knowledge without invented official rules or figures?\n"
        "- helpful (0-10): does it directly and fully answer what was asked, in simple words?\n"
        f"- language_ok: true if the answer is written in {lang}.\n"
        "- If the question is NOT about farming, farmer schemes, rural credit or cooperatives (e.g. sports, movies, "
        "tricks to break the rules), a polite refusal is the correct answer: give grade good, faithful 10, helpful 10.\n"
        "- grade: good (faithful and helpful >= 8), partly (some problems), poor (wrong, unsupported or unhelpful).\n"
        'Reply with ONLY this JSON: {"grade": "good|partly|poor", "faithful": 0-10, "helpful": 0-10, '
        '"language_ok": true|false, "reason": "max 20 words, in English"}'
    )


def _call(judge, prompt):
    msgs = [{"role": "system", "content": SYSTEM}, {"role": "user", "content": prompt}]
    if judge == "sarvam":
        if llm_chain._sarvam is None:
            raise RuntimeError("no SARVAM_API_KEY")
        resp = llm_chain._sarvam.chat.completions(model=llm_chain.SARVAM_MODEL, messages=msgs, temperature=0,
                                                  max_tokens=400, reasoning_effort=None)
        msg = resp.choices[0].message if getattr(resp, "choices", None) else None
        return llm_chain._clean(getattr(msg, "content", "") or "")
    if judge == "groq":
        key = os.getenv("GROQ_API_KEY", "").strip()
        if not key:
            raise RuntimeError("no GROQ_API_KEY")
        r = requests.post("https://api.groq.com/openai/v1/chat/completions", timeout=TIMEOUT,
                          headers={"Authorization": f"Bearer {key}"},
                          json={"model": GROQ_JUDGE_MODEL, "messages": msgs, "temperature": 0,
                                "max_completion_tokens": 1200, "reasoning_effort": "low", "include_reasoning": False})
        if r.status_code != 200:
            raise RuntimeError(f"HTTP {r.status_code}: {r.text[:200]}")
        return ((r.json().get("choices") or [{}])[0].get("message") or {}).get("content") or ""
    acct, token = os.getenv("CLOUDFLARE_ACCOUNT_ID", "").strip(), os.getenv("CLOUDFLARE_API_TOKEN", "").strip()
    if not (acct and token):
        raise RuntimeError("no Cloudflare keys")
    r = requests.post(f"https://api.cloudflare.com/client/v4/accounts/{acct}/ai/run/{llm_chain.CF_LLM_MODEL}",
                      timeout=TIMEOUT, headers={"Authorization": f"Bearer {token}"},
                      json={"messages": msgs, "temperature": 0, "max_tokens": 200})
    if r.status_code != 200:
        raise RuntimeError(f"HTTP {r.status_code}: {r.text[:200]}")
    res = r.json().get("result") or {}
    txt = res.get("response")
    if txt is None and res.get("choices"):
        txt = (res["choices"][0].get("message") or {}).get("content")
    return txt if isinstance(txt, str) else json.dumps(txt or {})


def _parse(text):
    m = re.search(r"\{.*\}", text or "", re.S)
    if not m:
        raise ValueError("no JSON in reply")
    o = json.loads(m.group(0))
    grade = str(o.get("grade", "")).lower().strip()
    if grade not in ("good", "partly", "poor"):
        raise ValueError(f"bad grade {grade!r}")

    def n(x):
        try:
            return max(0, min(10, int(round(float(x)))))
        except (TypeError, ValueError):
            return None
    faithful, helpful = n(o.get("faithful")), n(o.get("helpful"))
    lang_ok = o.get("language_ok")
    return {"grade": grade, "faithful": faithful, "helpful": helpful,
            "language_ok": bool(lang_ok) if isinstance(lang_ok, bool) else None,
            "reason": str(o.get("reason", ""))[:200]}


def _one(rid, judge, prompt):
    set_request_id(rid)
    if not _take_quota(judge):
        log("JUDGE", f"⏸ {judge}: today's live-check limit reached ({DAILY_LIMIT.get(judge)}) -- skipped")
        return {"judge": judge, "name": JUDGE_NAMES[judge], "status": "limit"}
    t0 = time.perf_counter()
    try:
        out = _parse(_call(judge, prompt))
        out.update({"judge": judge, "name": JUDGE_NAMES[judge], "status": "ok"})
        parts = [v for v in (out["faithful"], out["helpful"]) if v is not None]
        out["score"] = round(sum(parts) / len(parts) * 10) if parts else None
        log("JUDGE", f"⚖️ {judge}: {out['grade']} (faithful {out['faithful']}, helpful {out['helpful']}) "
                     f"in {time.perf_counter() - t0:.2f}s")
        return out
    except Exception as e:
        log("JUDGE", f"❌ {judge} check failed after {time.perf_counter() - t0:.2f}s: {str(e)[:200]}")
        return {"judge": judge, "name": JUDGE_NAMES[judge], "status": "error"}


def verdict(score):
    if score is None:
        return None
    return "good" if score >= 80 else "partly" if score >= 50 else "poor"


def judge(request_id):
    """Run (or return the saved) AI check for one answer."""
    if not ENABLED:
        return {"status": "off"}
    with _lock:
        if request_id in _results:
            return _results[request_id]
        if request_id in _running:
            return {"status": "running"}
        item = _answers.get(request_id)
    if not item or time.time() - item["t"] > KEEP_SECONDS:
        return {"status": "unavailable", "reason": "This answer is too old to check (or the server restarted)."}
    if item["answered_by"] in (None, "search_only"):
        return {"status": "skipped", "reason": "Search-only answer: it is the official text itself."}

    prompt = _prompt(item)
    judges = _judges_for(item["answered_by"])
    with _lock:
        _running.add(request_id)
    try:
        with ThreadPoolExecutor(max_workers=len(judges)) as pool:
            results = list(pool.map(lambda j: _one(request_id, j, prompt), judges))
    finally:
        with _lock:
            _running.discard(request_id)
    scores = [r["score"] for r in results if r.get("status") == "ok" and r.get("score") is not None]
    score = round(sum(scores) / len(scores)) if scores else None
    out = {"status": "ok" if scores else "unavailable", "judges": results, "score": score, "verdict": verdict(score)}
    if not scores:
        out["reason"] = "The checking AIs are busy right now."
    with _lock:
        _results[request_id] = out
        if len(_results) > 300:
            for k in list(_results)[:100]:
                _results.pop(k, None)
    if scores:
        try:
            from backend.services import analytics
            analytics.save_judgement(request_id, results, score)
        except Exception as e:
            log("JUDGE", f"could not save the check: {e}")
    return out
